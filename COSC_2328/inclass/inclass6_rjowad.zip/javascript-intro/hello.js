const firstName = 'Rifat Abrar';
const lastName = 'Jowad';
const year = 2027; 
console.log('My name: ' + firstName + ' ' + lastName);
console.log('Years remaining: ' + (year - 2024));
